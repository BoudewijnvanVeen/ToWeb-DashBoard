
import React, { PropTypes }  from 'react';

import Column from './Column'
import Tile from './Tile'

import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';

class DashBoard extends React.Component {
  render() {
    return (
      <div className='dashboard'>
        <Column> {this.props.Tiles.filter((t) => t.col === 1).map((tile) => <Tile key={tile.id} tile={tile} />)} </Column>
        <Column> {this.props.Tiles.filter((t) => t.col === 2).map((tile) => <Tile key={tile.id} tile={tile} />)} </Column>
      </div>
    );
  }
}

DashBoard.PropTypes = {
    tiles: PropTypes.arrayOf(PropTypes.object).isRequired   
}

export default DragDropContext(HTML5Backend)(DashBoard);