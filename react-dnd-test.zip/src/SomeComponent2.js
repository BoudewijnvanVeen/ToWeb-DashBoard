
import React  from 'react';

class SomeComponent2 extends React.Component {
  render() {
    return (
      <div>
        Hello world 2
      </div>
    );
  }
}

export default SomeComponent2;