
import React  from 'react';

class SomeComponent1 extends React.Component {
  render() {
    return (
      <div>
        Hello world 1
      </div>
    );
  }
}

export default SomeComponent1;